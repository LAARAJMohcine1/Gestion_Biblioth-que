/**
 * 
 */
/**
 * 
 */
module GestionBibliotheque {
	requires java.desktop;
}